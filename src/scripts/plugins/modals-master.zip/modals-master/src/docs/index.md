<p><button data-modal="#modal1">Modal</button> <button data-modal="#modal2">Modal Medium</button> <button data-modal="#modal3">Modal Small</button></p>

<div class="modal" data-modal-window id="modal1">
	<a  class="close" data-modal-close href="#">x</a>
	<h3>Modal</h3>
	<p>Modal content</p>
	<button data-modal-close>Close</button>
</div>

<div class="modal modal-medium" data-modal-window id="modal2">
	<a  class="close" data-modal-close href="#">x</a>
	<h3>Modal Medium</h3>
	<p>Modal content</p>
	<button data-modal-close>Close</button>
</div>

<div class="modal modal-small" data-modal-window id="modal3">
	<a class="close" data-modal-close href="#">x</a>
	<h3>Modal Small</h3>
	<p>Modal content</p>
	<button data-modal-close>Close</button>
</div>